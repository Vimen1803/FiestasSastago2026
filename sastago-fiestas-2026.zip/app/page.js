import Header from '../components/Header';
import DayTicket from '../components/DayTicket';
import { DAYS } from '../data/events';

const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Festival',
  name: 'Fiestas de San Roque y la Virgen de Montler',
  startDate: '2026-08-13',
  endDate: '2026-08-18',
  eventAttendanceMode: 'https://schema.org/OfflineEventAttendanceMode',
  eventStatus: 'https://schema.org/EventScheduled',
  location: {
    '@type': 'Place',
    name: 'Sástago',
    address: {
      '@type': 'PostalAddress',
      addressLocality: 'Sástago',
      addressRegion: 'Zaragoza',
      addressCountry: 'ES',
    },
  },
  description:
    'Programa de las Fiestas de San Roque y la Virgen de Montler en Sástago, del 13 al 18 de agosto de 2026.',
};

export default function HomePage() {
  return (
    <div className="relative min-h-[100dvh]">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <div className="cover-bg" aria-hidden="true" />

      <div className="relative z-10">
        <Header />

        <main className="px-4 pt-8 pb-8">
          <h2 className="font-body text-[11px] uppercase tracking-[0.3em] text-gold-400 mb-3 px-1">
            Elige un día
          </h2>
          <div className="flex flex-col gap-3">
            {DAYS.map((d) => (
              <DayTicket
                key={d.day}
                day={d.day}
                weekday={d.weekday}
                tag={d.tag}
                eventCount={d.events.length}
              />
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
