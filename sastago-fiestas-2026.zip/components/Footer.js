export default function Footer() {
  return (
    <footer className="px-6 py-8 text-center border-t border-white/5 mt-4">
      <p className="font-body text-[11px] tracking-[0.2em] uppercase text-mist-400">
        Fiestas de Sástago · Del 13 al 18 de agosto de 2026
      </p>
      <p className="font-body text-xs text-mist-400/70 mt-2">
        Página hecha por Víctor Menjón
      </p>
    </footer>
  );
}
