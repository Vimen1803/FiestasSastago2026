import Link from 'next/link';

function CalendarIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <rect x="3" y="5" width="18" height="16" rx="3" stroke="#f3bd3a" strokeWidth="1.8" />
      <path d="M3 10h18" stroke="#f3bd3a" strokeWidth="1.8" />
      <path d="M8 3v4M16 3v4" stroke="#f3bd3a" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

export default function DayTicket({ day, weekday, tag, eventCount }) {
  return (
    <Link
      href={`/dia/${day}`}
      className="day-card group flex items-stretch rounded-2xl overflow-hidden"
    >
      <div className="day-card-gold w-[76px] shrink-0 flex flex-col items-center justify-center py-4">
        <span className="font-display text-3xl leading-none text-navy-950">{day}</span>
        <span className="font-body text-[10px] font-medium uppercase tracking-widest text-navy-950/80 mt-1">
          agosto
        </span>
      </div>

      <div className="flex-1 flex items-center gap-3 pl-4 pr-3 py-3.5 min-w-0">
        <div className="shrink-0 w-9 h-9 rounded-full bg-navy-950/50 flex items-center justify-center">
          <CalendarIcon />
        </div>

        <div className="min-w-0 flex-1">
          <p className="font-display text-lg text-cream-50 leading-none">{weekday}</p>
          <p className="font-body text-xs text-mist-400 mt-1">
            {eventCount} {eventCount === 1 ? 'acto' : 'actos'}
            {tag ? ` · ${tag}` : ''}
          </p>
        </div>

        <div className="shrink-0 w-9 h-9 rounded-full bg-navy-950/50 flex items-center justify-center text-gold-400 group-hover:translate-x-0.5 transition-transform">
          <span aria-hidden="true">›</span>
        </div>
      </div>
    </Link>
  );
}
